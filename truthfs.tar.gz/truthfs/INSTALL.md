# TruthFS Installation & Quick Start Guide

## Installation

### Prerequisites

- Python 3.9 or higher
- GCC compiler (for native extensions)
- pip package manager

### Install from Source

```bash
# Clone the repository (or extract the tarball)
cd truthfs/

# Install dependencies
pip install --break-system-packages -r requirements.txt

# Install TruthFS
pip install --break-system-packages -e .

# Verify installation
python -c "import truthfs; print('TruthFS installed successfully!')"
```

### Quick Install with Make

```bash
cd truthfs/
make install
```

## Quick Start

### 1. Run the Complete Demo

```bash
# Run the comprehensive demonstration
python examples/complete_demo.py
```

This will demonstrate:
- System initialization
- Data writing with integrity verification
- Deduplication
- Snapshot creation (O(1) time!)
- Copy-on-Write modifications
- Integrity verification
- Corruption detection
- Snapshot rollback
- Audit log verification
- Complete statistics

### 2. Test Individual Components

#### Hash Functions & Merkle Trees

```bash
cd src/truthfs/core
python hash.py
```

Output shows:
- SHA-256 hashing
- Avalanche effect demonstration
- Merkle tree construction
- Proof generation and verification

#### XOR Parity (RAID-5)

```bash
cd src/truthfs/redundancy
python xor.py
```

Output shows:
- XOR parity calculation
- Block recovery from parity
- RAID-5 layout
- Disk failure simulation

#### Reed-Solomon (RAID-6)

```bash
cd src/truthfs/redundancy
python reed_solomon.py
```

Output shows:
- Galois Field operations
- Reed-Solomon encoding
- Recovery from multiple erasures
- RAID-6 functionality

#### Copy-on-Write & Snapshots

```bash
cd src/truthfs/core
python cow.py
```

Output shows:
- CoW write operations
- Instant snapshot creation
- Space usage calculations
- Snapshot rollback

### 3. Use the Main System

```python
from truthfs import TruthFS, TruthFSConfig, RedundancyMode, HashAlgorithm

# Configure system
config = TruthFSConfig(
    total_blocks=100000,
    block_size=4096,
    hash_algorithm=HashAlgorithm.SHA256,
    redundancy_mode=RedundancyMode.RAID6,
    enable_dedup=True,
    enable_audit=True
)

# Initialize TruthFS
fs = TruthFS(config)

# Write data
data = b"Hello, TruthFS!" + b"\x00" * 4082  # Pad to 4096 bytes
fs.write(0, data)

# Read data
retrieved = fs.read(0)

# Create snapshot
snapshot_id = fs.create_snapshot("Test Snapshot")

# Modify data
new_data = b"Modified data!" + b"\x00" * 4082
fs.write(0, new_data)

# Rollback to snapshot
fs.rollback_snapshot(snapshot_id)

# Verify integrity
all_valid, corrupted = fs.verify_integrity()

# Get statistics
stats = fs.get_stats()
print(stats)
```

### 4. Command-Line Interface

```bash
# Create volume (simulated)
python src/truthfs/api/cli.py create /dev/demo --size 1000000000 --dedup --audit

# Show statistics
python src/truthfs/api/cli.py stats /dev/demo

# Create snapshot
python src/truthfs/api/cli.py snapshot create /dev/demo --name backup-2025-02-03

# List snapshots
python src/truthfs/api/cli.py snapshot list /dev/demo

# Verify integrity
python src/truthfs/api/cli.py verify /dev/demo

# Enable scrubbing
python src/truthfs/api/cli.py scrub enable /dev/demo --schedule daily --repair

# Verify audit log
python src/truthfs/api/cli.py audit verify /dev/demo
```

## What's Included

### Core Mathematical Components

1. **Hash Functions** (`src/truthfs/core/hash.py`)
   - SHA-256 and SHA-512 implementation
   - Merkle tree construction
   - O(log n) proof generation
   - Integrity verification

2. **XOR Parity** (`src/truthfs/redundancy/xor.py`)
   - RAID-5 implementation
   - Single disk failure recovery
   - Stripe management

3. **Reed-Solomon** (`src/truthfs/redundancy/reed_solomon.py`)
   - Galois Field GF(2^8) mathematics
   - RAID-6 dual parity
   - Configurable (k,n) erasure coding
   - Multi-disk failure recovery

4. **Copy-on-Write** (`src/truthfs/core/cow.py`)
   - O(1) snapshot creation
   - Reference counting
   - Garbage collection
   - Version management

5. **Integrated System** (`src/truthfs/__init__.py`)
   - Complete TruthFS implementation
   - All components working together
   - Deduplication engine
   - Audit logging
   - Statistics and monitoring

### API Interfaces

1. **Python API** (`src/truthfs/__init__.py`)
   - Native Python interface
   - Full programmatic control

2. **Command-Line Interface** (`src/truthfs/api/cli.py`)
   - Complete CLI tool
   - All operations accessible from shell

### Examples

1. **Complete Demo** (`examples/complete_demo.py`)
   - Comprehensive system demonstration
   - All features exercised
   - Performance measurements

## Testing

Each component includes built-in demonstration code. Run them directly:

```bash
# Test all components
python src/truthfs/core/hash.py
python src/truthfs/redundancy/xor.py
python src/truthfs/redundancy/reed_solomon.py
python src/truthfs/core/cow.py
python src/truthfs/__init__.py
```

## Mathematical Guarantees

TruthFS provides mathematical guarantees for:

1. **Data Integrity**
   - Collision resistance: P(collision) < 2^-256
   - Every block cryptographically verified
   - Merkle tree for O(log n) verification

2. **Fault Tolerance**
   - RAID-5: Survives 1 disk failure
   - RAID-6: Survives 2 disk failures
   - Erasure (k,n): Survives n-k failures
   - Perfect reconstruction guaranteed

3. **Versioning**
   - O(1) snapshot creation
   - Space = Base + Σ(changes per version)
   - Reference counting ensures correctness

4. **Deduplication**
   - Identical data stored once
   - Hash-based content addressing
   - Automatic space savings

5. **Audit Trail**
   - Cryptographically chained events
   - Tamper detection guaranteed
   - Non-repudiation through signatures

## Architecture

```
User Application
      ↓
Python API / CLI
      ↓
TruthFS Core Engine
      ↓
┌─────────────────────────┐
│  Deduplication Layer    │
├─────────────────────────┤
│  Integrity Layer        │  ← Merkle Trees & Hashes
├─────────────────────────┤
│  Copy-on-Write Layer    │  ← Snapshots & Versioning
├─────────────────────────┤
│  Redundancy Layer       │  ← RAID-5/6, Erasure Coding
├─────────────────────────┤
│  Block Storage          │
└─────────────────────────┘
      ↓
Physical Storage Device
```

## Performance Characteristics

- **Write**: O(1) with dedup table lookup
- **Read**: O(1) with optional O(log n) verification
- **Snapshot Create**: O(1) - constant time!
- **Snapshot Rollback**: O(1) metadata swap
- **Integrity Check**: O(n log n) for full verification
- **Deduplication**: O(1) hash lookup

## Next Steps

1. Review the mathematical foundations in `/mnt/user-data/outputs/storage_math_research.md`
2. Read the detailed explanation in `/mnt/user-data/outputs/layered_storage_math_explained.md`
3. Run `python examples/complete_demo.py` for full demonstration
4. Explore individual components in `src/truthfs/`
5. Integrate TruthFS into your application

## Support

For questions or issues:
- Check the README.md for detailed documentation
- Review the mathematical research papers
- Examine example code in `examples/`
- Run built-in demos in each module

---

**TruthFS - Where Mathematics Meets Storage Reality**
