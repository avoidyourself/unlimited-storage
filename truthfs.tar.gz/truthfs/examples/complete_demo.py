#!/usr/bin/env python3
"""
TruthFS Complete Usage Example

Demonstrates all features of the TruthFS system:
1. System initialization with configuration
2. Writing data with automatic integrity verification
3. Deduplication in action
4. Snapshot creation (O(1) time)
5. Data modification with Copy-on-Write
6. Integrity verification
7. Corruption detection and recovery
8. Snapshot rollback
9. Audit log verification
10. Statistics and reporting
"""

import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from truthfs import TruthFS, TruthFSConfig, RedundancyMode, HashAlgorithm
import time


def print_section(title):
    """Print section header"""
    print(f"\n{'=' * 70}")
    print(f"  {title}")
    print('=' * 70)


def main():
    print_section("TruthFS Complete System Demonstration")
    
    # ========================================================================
    # 1. SYSTEM INITIALIZATION
    # ========================================================================
    print_section("1. System Initialization")
    
    config = TruthFSConfig(
        total_blocks=100000,        # 100,000 blocks
        block_size=4096,            # 4 KB blocks = 400 MB total
        hash_algorithm=HashAlgorithm.SHA256,
        redundancy_mode=RedundancyMode.RAID6,  # Dual parity
        enable_dedup=True,          # Content-addressable storage
        enable_compression=False,   # Disabled for this demo
        enable_encryption=False,    # Disabled for this demo
        enable_audit=True           # Blockchain-style audit log
    )
    
    print("Creating TruthFS instance...")
    start_time = time.time()
    fs = TruthFS(config)
    init_time = time.time() - start_time
    
    print(f"✓ TruthFS initialized in {init_time:.3f} seconds")
    print(f"\nConfiguration:")
    print(f"  - Capacity: {config.total_blocks * config.block_size / (1024**2):.1f} MB")
    print(f"  - Block size: {config.block_size} bytes")
    print(f"  - Hash algorithm: {config.hash_algorithm.value}")
    print(f"  - Redundancy: {config.redundancy_mode.value}")
    print(f"  - Deduplication: {'✓ enabled' if config.enable_dedup else '✗ disabled'}")
    print(f"  - Audit logging: {'✓ enabled' if config.enable_audit else '✗ disabled'}")
    
    # ========================================================================
    # 2. WRITING DATA WITH INTEGRITY
    # ========================================================================
    print_section("2. Writing Data with Automatic Integrity Verification")
    
    print("Writing 1,000 data blocks...")
    start_time = time.time()
    
    for i in range(1000):
        # Create sample data
        data = f"Data block {i:04d} - This is sample content for testing TruthFS".ljust(4096, 'X').encode()
        
        # Write with automatic:
        # - Hash calculation
        # - Deduplication check
        # - Copy-on-Write allocation
        # - Audit log entry
        fs.write(i, data)
        
        if (i + 1) % 250 == 0:
            print(f"  Progress: {i + 1}/1000 blocks written")
    
    write_time = time.time() - start_time
    
    print(f"\n✓ Wrote 1,000 blocks in {write_time:.2f} seconds")
    print(f"  Throughput: {(1000 * 4096) / (1024**2) / write_time:.1f} MB/s")
    
    stats = fs.get_stats()
    print(f"\nStorage statistics:")
    print(f"  - Physical blocks: {stats['storage']['physical_blocks_used']:,}")
    print(f"  - Logical blocks: {stats['storage']['logical_blocks']:,}")
    print(f"  - Free blocks: {stats['storage']['free_blocks']:,}")
    
    # ========================================================================
    # 3. DEDUPLICATION IN ACTION
    # ========================================================================
    print_section("3. Deduplication Demonstration")
    
    print("Writing duplicate data...")
    
    # Write the same content 100 times
    duplicate_data = b"X" * 4096
    
    start_time = time.time()
    for i in range(2000, 2100):
        fs.write(i, duplicate_data)
    dedup_time = time.time() - start_time
    
    stats = fs.get_stats()
    
    print(f"\n✓ Wrote 100 duplicate blocks in {dedup_time:.3f} seconds")
    print(f"\nDeduplication results:")
    print(f"  - Blocks deduplicated: {stats['blocks_deduped']}")
    print(f"  - Dedup ratio: {stats['storage']['dedup_ratio']:.2f}x")
    print(f"  - Space saved: Only 1 physical block for 100 logical blocks!")
    
    # ========================================================================
    # 4. SNAPSHOT CREATION (O(1) TIME!)
    # ========================================================================
    print_section("4. Snapshot Creation (O(1) Complexity)")
    
    print("Creating first snapshot...")
    start_time = time.time()
    snapshot1_id = fs.create_snapshot("Baseline")
    snapshot1_time = time.time() - start_time
    
    print(f"✓ Snapshot 'Baseline' created in {snapshot1_time:.6f} seconds")
    print(f"  Snapshot ID: {snapshot1_id}")
    print(f"  Time complexity: O(1) - constant time regardless of data size!")
    
    # ========================================================================
    # 5. DATA MODIFICATION WITH COPY-ON-WRITE
    # ========================================================================
    print_section("5. Data Modification (Copy-on-Write)")
    
    print("Modifying 500 blocks...")
    start_time = time.time()
    
    for i in range(500):
        modified_data = f"MODIFIED block {i:04d} - Updated content".ljust(4096, 'Y').encode()
        fs.write(i, modified_data)
    
    modify_time = time.time() - start_time
    
    print(f"\n✓ Modified 500 blocks in {modify_time:.2f} seconds")
    print(f"\nCopy-on-Write in action:")
    print(f"  - Original blocks preserved (for snapshot)")
    print(f"  - New blocks allocated for modifications")
    print(f"  - Old blocks will be garbage collected when snapshot is deleted")
    
    stats = fs.get_stats()
    print(f"\nStorage after modifications:")
    print(f"  - Physical blocks: {stats['storage']['physical_blocks_used']:,}")
    print(f"  - Space overhead: {(stats['storage']['physical_blocks_used'] - stats['storage']['logical_blocks'])} blocks for versioning")
    
    # ========================================================================
    # 6. CREATE ANOTHER SNAPSHOT
    # ========================================================================
    print_section("6. Second Snapshot Creation")
    
    print("Creating snapshot after modifications...")
    start_time = time.time()
    snapshot2_id = fs.create_snapshot("After Modifications")
    snapshot2_time = time.time() - start_time
    
    print(f"✓ Snapshot 'After Modifications' created in {snapshot2_time:.6f} seconds")
    print(f"  Snapshot ID: {snapshot2_id}")
    
    stats = fs.get_stats()
    print(f"\nTotal snapshots: {len(stats['snapshots']['list'])}")
    for snap in stats['snapshots']['list']:
        print(f"  - {snap['name']} (ID: {snap['id']}) - {snap['datetime']}")
    
    # ========================================================================
    # 7. INTEGRITY VERIFICATION
    # ========================================================================
    print_section("7. Integrity Verification")
    
    print("Verifying integrity of all blocks...")
    print("This uses Merkle tree for O(log n) verification per block")
    
    start_time = time.time()
    all_valid, corrupted_blocks = fs.verify_integrity()
    verify_time = time.time() - start_time
    
    print(f"\n✓ Integrity verification completed in {verify_time:.2f} seconds")
    print(f"\nResults:")
    print(f"  - Status: {'✓ ALL BLOCKS VALID' if all_valid else '✗ CORRUPTION DETECTED'}")
    print(f"  - Blocks checked: {stats['storage']['logical_blocks']}")
    print(f"  - Corruptions found: {len(corrupted_blocks)}")
    print(f"  - Total integrity checks: {stats['integrity_checks']}")
    
    # ========================================================================
    # 8. SIMULATE CORRUPTION AND DETECTION
    # ========================================================================
    print_section("8. Corruption Detection")
    
    print("Simulating data corruption...")
    
    # Directly corrupt a block in the CoW engine (bypassing normal write)
    physical_addr = fs.cow.current_metadata[42]
    original_data = fs.cow.physical_blocks[physical_addr]
    corrupted_data = b"CORRUPTED!" + original_data[10:]
    fs.cow.physical_blocks[physical_addr] = corrupted_data
    
    print("Block 42 has been corrupted in memory")
    
    print("\nAttempting to read corrupted block with verification...")
    result = fs.read(42, verify=True)
    
    if result is None:
        print("✓ Corruption detected!")
        print("  - Hash mismatch identified")
        print("  - Block rejected")
        print("  - Recovery from redundancy layer would be attempted")
    
    # Restore block for demo
    fs.cow.physical_blocks[physical_addr] = original_data
    
    # ========================================================================
    # 9. SNAPSHOT ROLLBACK
    # ========================================================================
    print_section("9. Snapshot Rollback (Time Travel)")
    
    print("Current state:")
    current_block = fs.read(100)
    print(f"  Block 100: {current_block[:50]}...")
    
    print(f"\nRolling back to snapshot '{fs.cow.snapshots[snapshot1_id].name}'...")
    start_time = time.time()
    fs.rollback_snapshot(snapshot1_id)
    rollback_time = time.time() - start_time
    
    print(f"✓ Rollback completed in {rollback_time:.6f} seconds")
    
    print("\nAfter rollback:")
    restored_block = fs.read(100)
    print(f"  Block 100: {restored_block[:50]}...")
    
    print(f"\nVerification:")
    print(f"  - Blocks are different: {current_block != restored_block}")
    print(f"  - Successfully restored to earlier version!")
    
    # ========================================================================
    # 10. AUDIT LOG VERIFICATION
    # ========================================================================
    print_section("10. Audit Log (Blockchain-Style Integrity)")
    
    print("Verifying audit log chain integrity...")
    
    audit_valid, invalid_index = fs.verify_audit_log()
    
    print(f"\n✓ Audit log verification: {'VALID' if audit_valid else 'INVALID'}")
    
    stats = fs.get_stats()
    print(f"\nAudit log statistics:")
    print(f"  - Total events: {len(fs.audit_log)}")
    print(f"  - Chain integrity: {'✓ INTACT' if audit_valid else '✗ BROKEN'}")
    print(f"  - Hash chain: Every event cryptographically linked")
    
    print(f"\nRecent audit events:")
    for entry in fs.audit_log[-5:]:
        timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(entry['timestamp']))
        print(f"  - {timestamp} | {entry['type']}")
    
    # ========================================================================
    # 11. FINAL STATISTICS
    # ========================================================================
    print_section("11. Final System Statistics")
    
    final_stats = fs.get_stats()
    
    print("Operations:")
    print(f"  - Reads: {final_stats['reads']:,}")
    print(f"  - Writes: {final_stats['writes']:,}")
    print(f"  - Snapshots created: {final_stats['snapshots_created']}")
    print(f"  - Blocks deduplicated: {final_stats['blocks_deduped']}")
    print(f"  - Integrity checks: {final_stats['integrity_checks']}")
    print(f"  - Corruptions detected: {final_stats['corruptions_detected']}")
    print(f"  - Auto-repairs: {final_stats['auto_repairs']}")
    
    print(f"\nStorage efficiency:")
    print(f"  - Physical blocks used: {final_stats['storage']['physical_blocks_used']:,}")
    print(f"  - Logical blocks: {final_stats['storage']['logical_blocks']:,}")
    print(f"  - Free blocks: {final_stats['storage']['free_blocks']:,}")
    print(f"  - Deduplication ratio: {final_stats['storage']['dedup_ratio']:.2f}x")
    
    capacity_mb = config.total_blocks * config.block_size / (1024**2)
    used_mb = final_stats['storage']['physical_blocks_used'] * config.block_size / (1024**2)
    
    print(f"\nCapacity:")
    print(f"  - Total: {capacity_mb:.1f} MB")
    print(f"  - Used: {used_mb:.1f} MB ({(used_mb/capacity_mb*100):.1f}%)")
    print(f"  - Free: {(capacity_mb - used_mb):.1f} MB")
    
    print(f"\nData protection:")
    print(f"  - Redundancy: {config.redundancy_mode.value.upper()}")
    print(f"  - Hash algorithm: {config.hash_algorithm.value.upper()}")
    print(f"  - Fault tolerance: 2 simultaneous failures (RAID-6)")
    print(f"  - Integrity: Merkle tree verification")
    print(f"  - Audit trail: Cryptographically signed")
    
    # ========================================================================
    # SUMMARY
    # ========================================================================
    print_section("Summary: TruthFS Capabilities Demonstrated")
    
    print("""
✓ Hash Functions & Merkle Trees
  - Every block cryptographically hashed (SHA-256)
  - Merkle tree for O(log n) verification
  - Corruption detection with hash comparison

✓ XOR Parity & Reed-Solomon (RAID-6)
  - Dual parity for 2-disk failure tolerance
  - Galois Field GF(2^8) mathematics
  - Automatic reconstruction on failure

✓ Copy-on-Write & Snapshots
  - O(1) snapshot creation (instant!)
  - Zero initial space overhead
  - Full version history
  - Time-travel capability

✓ Content-Addressable Deduplication
  - Automatic duplicate detection
  - 1 physical copy for N identical blocks
  - Significant space savings

✓ Blockchain-Style Audit Log
  - Cryptographically chained events
  - Tamper-evident history
  - Forensic trail

✓ Complete Integration
  - All layers working together
  - Production-ready implementation
  - Based on proven mathematics
    """)
    
    print_section("TruthFS Demonstration Complete!")
    
    return 0


if __name__ == '__main__':
    sys.exit(main())
