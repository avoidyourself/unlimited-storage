"""
TruthFS Reed-Solomon Module - Advanced Erasure Coding

Implements:
- Reed-Solomon error correction codes
- RAID-6 dual parity (P and Q)
- Configurable (k, n) erasure coding
- Galois Field GF(2^8) mathematics

Mathematical Foundation:
- Polynomial interpolation over finite fields
- Can recover from up to (n - k) erasures
- Based on evaluation of polynomials at distinct points in GF(2^8)

Example:
- (10, 16) code: 10 data + 6 parity = 16 total
- Can lose ANY 6 blocks and still recover
- Storage overhead: 1.6x (vs 2x for mirroring)
"""

from typing import List, Optional, Tuple
import numpy as np
from dataclasses import dataclass


class GaloisField:
    """
    Galois Field GF(2^8) mathematics
    
    A finite field with 256 elements (0-255)
    Used for Reed-Solomon coding
    
    Operations:
    - Addition: XOR
    - Multiplication: Polynomial multiplication mod irreducible polynomial
    - Division: Multiplication by inverse
    
    Irreducible polynomial: x^8 + x^4 + x^3 + x + 1 (0x11b)
    """
    
    # Primitive polynomial: x^8 + x^4 + x^3 + x + 1
    PRIMITIVE_POLYNOMIAL = 0x11b
    
    def __init__(self):
        """Initialize lookup tables for fast operations"""
        self.exp_table = [0] * 512  # Exponentiation table
        self.log_table = [0] * 256  # Logarithm table
        self._generate_tables()
    
    def _generate_tables(self):
        """
        Generate exp and log tables for GF(2^8)
        
        These tables enable fast multiplication and division
        """
        x = 1
        for i in range(255):
            self.exp_table[i] = x
            self.log_table[x] = i
            
            # Multiply by generator element (x)
            x <<= 1
            if x & 0x100:  # If overflow
                x ^= self.PRIMITIVE_POLYNOMIAL
        
        # Extend exp table for convenience
        for i in range(255, 512):
            self.exp_table[i] = self.exp_table[i - 255]
    
    def multiply(self, a: int, b: int) -> int:
        """
        Multiply two elements in GF(2^8)
        
        Args:
            a, b: Elements in GF(2^8) (0-255)
            
        Returns:
            Product in GF(2^8)
            
        Algorithm:
            - If either is 0, return 0
            - Otherwise: exp[log[a] + log[b]]
        """
        if a == 0 or b == 0:
            return 0
        return self.exp_table[self.log_table[a] + self.log_table[b]]
    
    def divide(self, a: int, b: int) -> int:
        """
        Divide two elements in GF(2^8)
        
        Args:
            a, b: Elements in GF(2^8) (0-255)
            
        Returns:
            Quotient in GF(2^8)
            
        Algorithm:
            exp[log[a] - log[b] + 255]
        """
        if b == 0:
            raise ZeroDivisionError("Division by zero in GF(2^8)")
        if a == 0:
            return 0
        return self.exp_table[self.log_table[a] - self.log_table[b] + 255]
    
    def power(self, a: int, n: int) -> int:
        """
        Raise element to power in GF(2^8)
        
        Args:
            a: Base element
            n: Exponent
            
        Returns:
            a^n in GF(2^8)
        """
        if a == 0:
            return 0
        return self.exp_table[(self.log_table[a] * n) % 255]
    
    def inverse(self, a: int) -> int:
        """
        Multiplicative inverse in GF(2^8)
        
        Args:
            a: Element to invert
            
        Returns:
            a^(-1) such that a * a^(-1) = 1
        """
        if a == 0:
            raise ValueError("Zero has no inverse")
        return self.exp_table[255 - self.log_table[a]]


@dataclass
class ReedSolomonCode:
    """
    Reed-Solomon (n, k) code configuration
    
    Attributes:
        n: Total number of blocks (data + parity)
        k: Number of data blocks
        parity_count: n - k (number of parity blocks)
    """
    n: int  # Total blocks
    k: int  # Data blocks
    
    @property
    def parity_count(self) -> int:
        """Number of parity blocks"""
        return self.n - self.k
    
    @property
    def overhead(self) -> float:
        """Storage overhead ratio"""
        return self.n / self.k


class ReedSolomon:
    """
    Reed-Solomon erasure coding engine
    
    Can encode k data blocks into n total blocks,
    allowing recovery from loss of up to (n-k) blocks
    
    Example:
        RS(10, 16): 10 data + 6 parity
        Can lose any 6 blocks and still recover
    """
    
    def __init__(self, k: int, n: int):
        """
        Initialize Reed-Solomon encoder/decoder
        
        Args:
            k: Number of data blocks
            n: Total number of blocks (data + parity)
        """
        if k <= 0 or n <= k:
            raise ValueError("Need 0 < k < n")
        if n > 255:
            raise ValueError("n must be <= 255 (GF(2^8) limitation)")
        
        self.k = k
        self.n = n
        self.gf = GaloisField()
        
        # Generate encoding matrix
        self.encode_matrix = self._generate_encode_matrix()
    
    def _generate_encode_matrix(self) -> np.ndarray:
        """
        Generate encoding matrix for Reed-Solomon
        
        Matrix structure:
        [ 1   0   0  ...  0 ]  <- Identity matrix (k×k)
        [ 0   1   0  ...  0 ]     (preserves data blocks)
        [ ...            ... ]
        [ 0   0   0  ...  1 ]
        [ g^0 g^1 ... g^(k-1) ]  <- Parity rows
        [ g^0 g^2 ... g^(2k-2) ]    (generate parity)
        [ ...               ... ]
        
        Where g is a generator element in GF(2^8)
        """
        matrix = np.zeros((self.n, self.k), dtype=np.uint8)
        
        # Identity matrix for data blocks
        for i in range(self.k):
            matrix[i, i] = 1
        
        # Parity rows using Vandermonde matrix
        for i in range(self.k, self.n):
            for j in range(self.k):
                # g^(i*j) where g = 2 (generator)
                exponent = (i - self.k) * j
                matrix[i, j] = self.gf.exp_table[exponent % 255]
        
        return matrix
    
    def encode_blocks(self, data_blocks: List[bytes]) -> List[bytes]:
        """
        Encode data blocks with Reed-Solomon parity
        
        Args:
            data_blocks: k data blocks (all same size)
            
        Returns:
            n total blocks (k data + (n-k) parity)
            
        Algorithm:
            For each byte position:
                output[i] = Σ(encode_matrix[i,j] * data[j])
                            over GF(2^8)
        """
        if len(data_blocks) != self.k:
            raise ValueError(f"Expected {self.k} data blocks, got {len(data_blocks)}")
        
        block_size = len(data_blocks[0])
        
        # Verify all blocks same size
        for block in data_blocks:
            if len(block) != block_size:
                raise ValueError("All blocks must be same size")
        
        # Initialize output blocks
        encoded_blocks = [bytearray(block_size) for _ in range(self.n)]
        
        # Encode each byte position
        for byte_idx in range(block_size):
            # Get input bytes at this position
            input_bytes = [block[byte_idx] for block in data_blocks]
            
            # Calculate output bytes using matrix multiplication in GF(2^8)
            for i in range(self.n):
                result = 0
                for j in range(self.k):
                    result ^= self.gf.multiply(
                        self.encode_matrix[i, j],
                        input_bytes[j]
                    )
                encoded_blocks[i][byte_idx] = result
        
        return [bytes(block) for block in encoded_blocks]
    
    def decode_blocks(self, available_blocks: List[Optional[bytes]], 
                     available_indices: List[int]) -> List[bytes]:
        """
        Decode data from available blocks
        
        Args:
            available_blocks: Available blocks (with None for lost blocks)
            available_indices: Indices of available blocks
            
        Returns:
            Original k data blocks
            
        Algorithm:
            1. Extract available rows from encode matrix
            2. Invert the submatrix
            3. Multiply by available blocks to recover data
        """
        if len(available_indices) < self.k:
            raise ValueError(
                f"Need at least {self.k} blocks to recover, "
                f"got {len(available_indices)}"
            )
        
        # Take first k available blocks
        available_indices = available_indices[:self.k]
        available_blocks = [available_blocks[i] for i in available_indices]
        
        block_size = len(available_blocks[0])
        
        # Extract submatrix of available rows
        submatrix = self.encode_matrix[available_indices, :]
        
        # Invert the submatrix in GF(2^8)
        inv_matrix = self._invert_matrix(submatrix)
        
        # Decode each byte position
        decoded_blocks = [bytearray(block_size) for _ in range(self.k)]
        
        for byte_idx in range(block_size):
            # Get available bytes
            available_bytes = [block[byte_idx] for block in available_blocks]
            
            # Multiply by inverse matrix
            for i in range(self.k):
                result = 0
                for j in range(self.k):
                    result ^= self.gf.multiply(
                        inv_matrix[i, j],
                        available_bytes[j]
                    )
                decoded_blocks[i][byte_idx] = result
        
        return [bytes(block) for block in decoded_blocks]
    
    def _invert_matrix(self, matrix: np.ndarray) -> np.ndarray:
        """
        Invert matrix in GF(2^8)
        
        Uses Gaussian elimination in Galois Field
        """
        k = matrix.shape[0]
        
        # Create augmented matrix [A | I]
        augmented = np.zeros((k, 2*k), dtype=np.uint8)
        augmented[:, :k] = matrix
        for i in range(k):
            augmented[i, k+i] = 1
        
        # Forward elimination
        for i in range(k):
            # Find pivot
            if augmented[i, i] == 0:
                for j in range(i+1, k):
                    if augmented[j, i] != 0:
                        augmented[[i, j]] = augmented[[j, i]]
                        break
            
            # Make diagonal element 1
            pivot = augmented[i, i]
            if pivot != 0:
                pivot_inv = self.gf.inverse(pivot)
                for j in range(2*k):
                    augmented[i, j] = self.gf.multiply(augmented[i, j], pivot_inv)
            
            # Eliminate column
            for j in range(k):
                if i != j and augmented[j, i] != 0:
                    factor = augmented[j, i]
                    for col in range(2*k):
                        augmented[j, col] ^= self.gf.multiply(
                            factor,
                            augmented[i, col]
                        )
        
        # Extract inverse from [I | A^-1]
        return augmented[:, k:]


class RAID6:
    """
    RAID-6 using Reed-Solomon (n, n-2) code
    
    Provides dual parity:
    - P parity: Simple XOR
    - Q parity: Reed-Solomon over GF(2^8)
    
    Can survive loss of ANY 2 disks
    """
    
    def __init__(self, num_data_disks: int, block_size: int = 4096):
        """
        Initialize RAID-6
        
        Args:
            num_data_disks: Number of data disks
            block_size: Block size in bytes
        """
        self.num_data_disks = num_data_disks
        self.block_size = block_size
        
        # Use RS(n-2, n) where n = num_data_disks + 2
        self.rs = ReedSolomon(
            k=num_data_disks,
            n=num_data_disks + 2
        )
    
    def encode(self, data_blocks: List[bytes]) -> Tuple[bytes, bytes]:
        """
        Encode data blocks to generate P and Q parity
        
        Args:
            data_blocks: Data blocks
            
        Returns:
            (P parity, Q parity)
        """
        if len(data_blocks) != self.num_data_disks:
            raise ValueError(
                f"Expected {self.num_data_disks} blocks, "
                f"got {len(data_blocks)}"
            )
        
        encoded = self.rs.encode_blocks(data_blocks)
        
        # Last two blocks are P and Q parity
        return encoded[-2], encoded[-1]
    
    def decode(self, blocks: List[Optional[bytes]], 
               failed_indices: List[int]) -> List[bytes]:
        """
        Recover from disk failures
        
        Args:
            blocks: All blocks (None for failed disks)
            failed_indices: Indices of failed disks
            
        Returns:
            Complete data blocks
        """
        if len(failed_indices) > 2:
            raise ValueError("RAID-6 can only recover from 2 failures")
        
        # Get available blocks and indices
        available_blocks = []
        available_indices = []
        
        for i, block in enumerate(blocks):
            if block is not None:
                available_blocks.append(block)
                available_indices.append(i)
        
        # Decode using Reed-Solomon
        all_blocks = self.rs.decode_blocks(available_blocks, available_indices)
        
        # Return only data blocks (not parity)
        return all_blocks[:self.num_data_disks]


if __name__ == "__main__":
    print("TruthFS Reed-Solomon Module Demo")
    print("=" * 60)
    
    # 1. Galois Field operations
    print("\n1. Galois Field GF(2^8) Operations:")
    gf = GaloisField()
    
    a, b = 53, 179
    print(f"   a = {a}, b = {b}")
    print(f"   a × b = {gf.multiply(a, b)}")
    print(f"   a ÷ b = {gf.divide(a, b)}")
    print(f"   a^(-1) = {gf.inverse(a)}")
    print(f"   a × a^(-1) = {gf.multiply(a, gf.inverse(a))} (should be 1)")
    
    # 2. Reed-Solomon encoding
    print("\n2. Reed-Solomon (4, 6) Code:")
    rs = ReedSolomon(k=4, n=6)
    
    # Create sample data blocks
    data = [f"Data block {i}".ljust(16).encode() for i in range(4)]
    
    print(f"   Data blocks: {len(data)}")
    for i, block in enumerate(data):
        print(f"     Block {i}: {block[:16]}")
    
    # Encode
    encoded = rs.encode_blocks(data)
    print(f"\n   Encoded blocks: {len(encoded)}")
    print(f"   Parity blocks: {len(encoded) - len(data)}")
    
    # 3. Recovery from erasures
    print("\n3. Recovery Test (2 blocks lost):")
    
    # Simulate losing blocks 1 and 3
    available = encoded.copy()
    available[1] = None
    available[3] = None
    available_indices = [i for i in range(6) if i not in [1, 3]]
    
    print(f"   Lost blocks: 1, 3")
    print(f"   Available blocks: {available_indices}")
    
    # Recover
    recovered = rs.decode_blocks(available, available_indices)
    
    print(f"\n   Original data blocks: {len(data)}")
    print(f"   Recovered blocks: {len(recovered)}")
    print(f"   Perfect recovery: {recovered == data}")
    
    # 4. RAID-6 demonstration
    print("\n4. RAID-6 (6 data disks + 2 parity):")
    raid6 = RAID6(num_data_disks=6, block_size=16)
    
    # Create data
    data_disks = [f"Disk{i}".ljust(16).encode() for i in range(6)]
    
    print(f"   Data disks: {len(data_disks)}")
    
    # Generate parity
    p_parity, q_parity = raid6.encode(data_disks)
    print(f"   P parity: {p_parity.hex()[:16]}...")
    print(f"   Q parity: {q_parity.hex()[:16]}...")
    
    # Simulate 2 disk failures
    all_blocks = data_disks + [p_parity, q_parity]
    all_blocks[2] = None  # Disk 2 failed
    all_blocks[5] = None  # Disk 5 failed
    
    print(f"\n   Simulating failure of disks 2 and 5...")
    
    # Recover
    recovered_data = raid6.decode(all_blocks, [2, 5])
    
    print(f"   Original: {data_disks[2][:10]}...")
    print(f"   Recovered: {recovered_data[2][:10]}...")
    print(f"   Match: {recovered_data[2] == data_disks[2]}")
    
    print("\n" + "=" * 60)
    print("Demo complete!")
