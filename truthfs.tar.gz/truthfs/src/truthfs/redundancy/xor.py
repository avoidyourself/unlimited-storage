"""
TruthFS XOR Parity Module - RAID-5 Style Redundancy

Implements:
- XOR parity calculation across multiple blocks
- Single block recovery from parity
- Stripe-based data organization

Mathematical Foundation:
- XOR properties: A ⊕ B ⊕ C ⊕ P = 0
- Recovery: If B is lost, B = A ⊕ C ⊕ P
- Commutative: A ⊕ B = B ⊕ A
- Associative: (A ⊕ B) ⊕ C = A ⊕ (B ⊕ C)
- Self-inverse: A ⊕ A = 0
- Identity: A ⊕ 0 = A
"""

from typing import List, Optional
import numpy as np
from dataclasses import dataclass


@dataclass
class Stripe:
    """
    RAID-5 stripe containing data blocks and parity
    
    A stripe spans across multiple disks:
    Disk 1    Disk 2    Disk 3    Disk 4
    Data 0    Data 1    Data 2    Parity 0
    Data 3    Data 4    Parity 1  Data 5
    ...
    """
    stripe_id: int
    data_blocks: List[bytes]
    parity_block: bytes
    block_size: int


class XORParity:
    """
    XOR-based parity calculation for RAID-5
    
    Mathematical guarantee:
    - Can recover from ANY single block failure
    - Recovery is perfect (no data loss)
    - Computational complexity: O(n) where n = number of blocks
    """
    
    def __init__(self, num_data_blocks: int, block_size: int = 4096):
        """
        Initialize XOR parity engine
        
        Args:
            num_data_blocks: Number of data blocks per stripe
            block_size: Size of each block in bytes
        """
        self.num_data_blocks = num_data_blocks
        self.block_size = block_size
    
    def calculate_parity(self, data_blocks: List[bytes]) -> bytes:
        """
        Calculate XOR parity across data blocks
        
        Args:
            data_blocks: List of data blocks
            
        Returns:
            Parity block (XOR of all data blocks)
            
        Algorithm:
            P = D₀ ⊕ D₁ ⊕ D₂ ⊕ ... ⊕ Dₙ
            
        Complexity: O(n × block_size)
        
        Mathematical proof:
            P ⊕ D₀ ⊕ D₁ ⊕ ... ⊕ Dₙ = 0
            Therefore: P = D₀ ⊕ D₁ ⊕ ... ⊕ Dₙ
        """
        if not data_blocks:
            raise ValueError("Need at least one data block")
        
        # Verify all blocks are same size
        for block in data_blocks:
            if len(block) != self.block_size:
                raise ValueError(f"All blocks must be {self.block_size} bytes")
        
        # Initialize parity as zeros
        parity = bytearray(self.block_size)
        
        # XOR all data blocks
        for block in data_blocks:
            for i, byte in enumerate(block):
                parity[i] ^= byte
        
        return bytes(parity)
    
    def calculate_parity_fast(self, data_blocks: List[bytes]) -> bytes:
        """
        Fast parity calculation using NumPy
        
        Same algorithm as calculate_parity but vectorized
        Up to 10x faster for large blocks
        """
        if not data_blocks:
            raise ValueError("Need at least one data block")
        
        # Convert to numpy arrays for vectorized operations
        arrays = [np.frombuffer(block, dtype=np.uint8) for block in data_blocks]
        
        # XOR all arrays
        parity = arrays[0].copy()
        for arr in arrays[1:]:
            parity ^= arr
        
        return parity.tobytes()
    
    def recover_block(self, available_blocks: List[bytes], 
                      parity: bytes, lost_index: int) -> bytes:
        """
        Recover lost data block using XOR parity
        
        Args:
            available_blocks: All available data blocks (with None at lost_index)
            parity: Parity block
            lost_index: Index of lost block
            
        Returns:
            Recovered block data
            
        Algorithm:
            If D₁ is lost:
            D₁ = P ⊕ D₀ ⊕ D₂ ⊕ ... ⊕ Dₙ
            
        Mathematical proof:
            P = D₀ ⊕ D₁ ⊕ D₂ ⊕ ... ⊕ Dₙ
            P ⊕ D₀ ⊕ D₂ ⊕ ... ⊕ Dₙ = D₁
            (because D₀ ⊕ D₀ = 0, etc.)
        """
        # Start with parity
        recovered = bytearray(parity)
        
        # XOR with all available blocks
        for i, block in enumerate(available_blocks):
            if i != lost_index and block is not None:
                for j, byte in enumerate(block):
                    recovered[j] ^= byte
        
        return bytes(recovered)
    
    def verify_stripe(self, data_blocks: List[bytes], parity: bytes) -> bool:
        """
        Verify stripe integrity
        
        Args:
            data_blocks: Data blocks in stripe
            parity: Parity block
            
        Returns:
            True if parity is correct, False otherwise
            
        Verification:
            Calculate parity from data blocks
            Compare with stored parity
        """
        calculated_parity = self.calculate_parity(data_blocks)
        return calculated_parity == parity
    
    def create_stripe(self, stripe_id: int, data_blocks: List[bytes]) -> Stripe:
        """
        Create a complete stripe with data and parity
        
        Args:
            stripe_id: Unique stripe identifier
            data_blocks: Data blocks for this stripe
            
        Returns:
            Stripe object containing data and parity
        """
        if len(data_blocks) != self.num_data_blocks:
            raise ValueError(
                f"Expected {self.num_data_blocks} blocks, "
                f"got {len(data_blocks)}"
            )
        
        parity = self.calculate_parity_fast(data_blocks)
        
        return Stripe(
            stripe_id=stripe_id,
            data_blocks=data_blocks,
            parity_block=parity,
            block_size=self.block_size
        )


class RAID5Layout:
    """
    Complete RAID-5 layout manager
    
    Handles:
    - Stripe creation and management
    - Parity placement (rotating across disks)
    - Block recovery
    - Scrubbing and verification
    """
    
    def __init__(self, num_disks: int, block_size: int = 4096):
        """
        Initialize RAID-5 layout
        
        Args:
            num_disks: Total number of disks (minimum 3)
            block_size: Size of each block in bytes
        """
        if num_disks < 3:
            raise ValueError("RAID-5 requires at least 3 disks")
        
        self.num_disks = num_disks
        self.num_data_blocks = num_disks - 1  # One disk for parity
        self.block_size = block_size
        self.xor_engine = XORParity(self.num_data_blocks, block_size)
        
        # Storage: disk_id -> [blocks]
        self.disks: List[List[bytes]] = [[] for _ in range(num_disks)]
        self.stripes: List[Stripe] = []
    
    def write_stripe(self, data_blocks: List[bytes]) -> int:
        """
        Write a stripe across disks with rotating parity
        
        Args:
            data_blocks: Data blocks to write (num_disks - 1)
            
        Returns:
            Stripe ID
            
        Layout (for 4 disks):
        Stripe 0: [D0, D1, D2, P0]  (parity on disk 3)
        Stripe 1: [D3, D4, P1, D5]  (parity on disk 2)
        Stripe 2: [D6, P2, D7, D8]  (parity on disk 1)
        Stripe 3: [P3, D9, D10, D11] (parity on disk 0)
        """
        stripe_id = len(self.stripes)
        
        # Create stripe with parity
        stripe = self.xor_engine.create_stripe(stripe_id, data_blocks)
        
        # Determine parity disk (rotate)
        parity_disk = stripe_id % self.num_disks
        
        # Write blocks to disks
        data_idx = 0
        for disk_id in range(self.num_disks):
            if disk_id == parity_disk:
                # Write parity block
                self.disks[disk_id].append(stripe.parity_block)
            else:
                # Write data block
                self.disks[disk_id].append(stripe.data_blocks[data_idx])
                data_idx += 1
        
        self.stripes.append(stripe)
        return stripe_id
    
    def read_stripe(self, stripe_id: int, failed_disk: Optional[int] = None) -> List[bytes]:
        """
        Read stripe, recovering from failed disk if necessary
        
        Args:
            stripe_id: Stripe to read
            failed_disk: Disk that has failed (None if all healthy)
            
        Returns:
            Data blocks (excluding parity)
        """
        if stripe_id >= len(self.stripes):
            raise ValueError(f"Invalid stripe ID: {stripe_id}")
        
        stripe = self.stripes[stripe_id]
        parity_disk = stripe_id % self.num_disks
        
        if failed_disk is None:
            # No failure, just return data blocks
            return stripe.data_blocks.copy()
        
        # Recovery needed
        if failed_disk == parity_disk:
            # Parity disk failed, data is still intact
            return stripe.data_blocks.copy()
        
        # Data disk failed, need to recover
        # Collect available blocks
        available_blocks = []
        data_idx = 0
        lost_index = None
        
        for disk_id in range(self.num_disks):
            if disk_id == parity_disk:
                continue  # Skip parity disk
            
            if disk_id == failed_disk:
                available_blocks.append(None)
                lost_index = data_idx
            else:
                available_blocks.append(stripe.data_blocks[data_idx])
            
            data_idx += 1
        
        # Recover lost block
        recovered = self.xor_engine.recover_block(
            available_blocks,
            stripe.parity_block,
            lost_index
        )
        
        # Reconstruct data blocks
        result = available_blocks.copy()
        result[lost_index] = recovered
        
        return result
    
    def scrub_verify(self) -> List[Tuple[int, bool]]:
        """
        Verify all stripes for integrity
        
        Returns:
            List of (stripe_id, is_valid) tuples
            
        This simulates background scrubbing that detects
        silent data corruption
        """
        results = []
        
        for stripe_id, stripe in enumerate(self.stripes):
            is_valid = self.xor_engine.verify_stripe(
                stripe.data_blocks,
                stripe.parity_block
            )
            results.append((stripe_id, is_valid))
        
        return results
    
    def get_stats(self) -> dict:
        """Get RAID-5 statistics"""
        total_capacity = self.num_disks * len(self.disks[0]) * self.block_size
        usable_capacity = self.num_data_blocks * len(self.disks[0]) * self.block_size
        
        return {
            'num_disks': self.num_disks,
            'num_data_blocks_per_stripe': self.num_data_blocks,
            'block_size': self.block_size,
            'num_stripes': len(self.stripes),
            'total_capacity_bytes': total_capacity,
            'usable_capacity_bytes': usable_capacity,
            'overhead_percentage': (1 - usable_capacity / total_capacity) * 100,
            'fault_tolerance': 1  # Can survive 1 disk failure
        }


if __name__ == "__main__":
    print("TruthFS XOR Parity Module Demo")
    print("=" * 60)
    
    # 1. Basic XOR parity
    print("\n1. XOR Parity Calculation:")
    xor = XORParity(num_data_blocks=3, block_size=8)
    
    # Create sample data blocks
    block1 = b'\x11\x22\x33\x44\x55\x66\x77\x88'
    block2 = b'\xAA\xBB\xCC\xDD\xEE\xFF\x00\x11'
    block3 = b'\x12\x34\x56\x78\x9A\xBC\xDE\xF0'
    
    parity = xor.calculate_parity([block1, block2, block3])
    
    print(f"   Block 1: {block1.hex()}")
    print(f"   Block 2: {block2.hex()}")
    print(f"   Block 3: {block3.hex()}")
    print(f"   Parity:  {parity.hex()}")
    
    # 2. Block recovery
    print("\n2. Block Recovery (Block 2 lost):")
    recovered = xor.recover_block([block1, None, block3], parity, 1)
    print(f"   Original: {block2.hex()}")
    print(f"   Recovered: {recovered.hex()}")
    print(f"   Match: {recovered == block2}")
    
    # 3. RAID-5 layout
    print("\n3. RAID-5 Layout (4 disks):")
    raid5 = RAID5Layout(num_disks=4, block_size=16)
    
    # Write some stripes
    for i in range(4):
        data = [f"Data{i}-{j}".ljust(16).encode() for j in range(3)]
        stripe_id = raid5.write_stripe(data)
        print(f"   Written stripe {stripe_id}")
    
    stats = raid5.get_stats()
    print(f"\n   Stats:")
    print(f"   - Disks: {stats['num_disks']}")
    print(f"   - Stripes: {stats['num_stripes']}")
    print(f"   - Usable: {stats['usable_capacity_bytes']} bytes")
    print(f"   - Overhead: {stats['overhead_percentage']:.1f}%")
    print(f"   - Fault tolerance: {stats['fault_tolerance']} disk")
    
    # 4. Simulate disk failure
    print("\n4. Disk Failure Recovery:")
    print("   Simulating disk 2 failure...")
    
    # Read stripe 0 with disk 2 failed
    recovered_data = raid5.read_stripe(0, failed_disk=2)
    original_data = raid5.stripes[0].data_blocks
    
    print(f"   Original data blocks: {len(original_data)}")
    print(f"   Recovered data blocks: {len(recovered_data)}")
    print(f"   Data intact: {recovered_data == original_data}")
    
    # 5. Scrub verification
    print("\n5. Scrub Verification:")
    results = raid5.scrub_verify()
    all_valid = all(valid for _, valid in results)
    print(f"   Verified {len(results)} stripes")
    print(f"   All valid: {all_valid}")
    
    print("\n" + "=" * 60)
    print("Demo complete!")
