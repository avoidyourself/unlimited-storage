"""
TruthFS Hash Module - Cryptographic Hash Functions & Merkle Trees

Implements:
- SHA-256 and SHA-512 hashing
- Merkle tree construction and verification
- O(log n) proof generation and validation

Mathematical Foundation:
- Collision resistance: P(collision) < 2^-256
- Preimage resistance: computationally infeasible to reverse
- Avalanche effect: 1-bit change → completely different hash
"""

import hashlib
from typing import List, Tuple, Optional, Union
from dataclasses import dataclass
from enum import Enum
import math


class HashAlgorithm(Enum):
    """Supported hash algorithms"""
    SHA256 = "sha256"
    SHA512 = "sha512"
    
    @property
    def digest_size(self) -> int:
        """Get hash output size in bytes"""
        return {"sha256": 32, "sha512": 64}[self.value]


@dataclass
class MerkleProof:
    """
    Merkle proof for verifying a leaf without full tree
    
    Complexity: O(log n) storage and verification
    """
    leaf_index: int
    leaf_hash: bytes
    proof_hashes: List[Tuple[bytes, str]]  # (hash, 'left' or 'right')
    root_hash: bytes
    
    def verify(self) -> bool:
        """
        Verify this proof is valid
        
        Returns:
            True if proof is valid, False otherwise
            
        Complexity: O(log n) hash operations
        """
        current_hash = self.leaf_hash
        
        for sibling_hash, direction in self.proof_hashes:
            if direction == 'left':
                # Sibling is on left, current is on right
                combined = sibling_hash + current_hash
            else:
                # Current is on left, sibling is on right
                combined = current_hash + sibling_hash
            
            # Double SHA-256 (Bitcoin-style for extra security)
            current_hash = hashlib.sha256(
                hashlib.sha256(combined).digest()
            ).digest()
        
        return current_hash == self.root_hash


class HashFunction:
    """
    Cryptographic hash function wrapper
    
    Provides unified interface for different hash algorithms
    """
    
    def __init__(self, algorithm: HashAlgorithm = HashAlgorithm.SHA256):
        self.algorithm = algorithm
        self._hash_func = getattr(hashlib, algorithm.value)
    
    def hash(self, data: bytes) -> bytes:
        """
        Compute cryptographic hash of data
        
        Args:
            data: Input data to hash
            
        Returns:
            Hash digest (32 bytes for SHA-256, 64 bytes for SHA-512)
            
        Mathematical guarantee:
            - P(collision) < 2^-256 for SHA-256
            - P(collision) < 2^-512 for SHA-512
        """
        return self._hash_func(data).digest()
    
    def hash_blocks(self, blocks: List[bytes]) -> List[bytes]:
        """
        Hash multiple blocks efficiently
        
        Args:
            blocks: List of data blocks
            
        Returns:
            List of hash digests
        """
        return [self.hash(block) for block in blocks]
    
    def verify(self, data: bytes, expected_hash: bytes) -> bool:
        """
        Verify data matches expected hash
        
        Args:
            data: Data to verify
            expected_hash: Expected hash value
            
        Returns:
            True if hash matches, False otherwise
        """
        computed_hash = self.hash(data)
        return computed_hash == expected_hash


class MerkleTree:
    """
    Merkle Tree for hierarchical data integrity verification
    
    Mathematical properties:
    - Tree height: O(log n) for n leaves
    - Proof size: O(log n) hashes
    - Verification: O(log n) hash operations
    - Construction: O(n) hash operations
    
    Example:
        For 1,048,576 blocks (2^20):
        - Tree height: 20 levels
        - Proof size: 20 × 32 bytes = 640 bytes (SHA-256)
        - Verification: 20 hash operations (~50 microseconds)
    """
    
    def __init__(self, algorithm: HashAlgorithm = HashAlgorithm.SHA256):
        self.algorithm = algorithm
        self.hash_func = HashFunction(algorithm)
        self.leaves: List[bytes] = []
        self.tree: List[List[bytes]] = []
        self.root_hash: Optional[bytes] = None
    
    def build(self, data_blocks: List[bytes]) -> bytes:
        """
        Build Merkle tree from data blocks
        
        Args:
            data_blocks: List of data blocks to include in tree
            
        Returns:
            Root hash of the tree
            
        Complexity: O(n) where n = len(data_blocks)
        
        Algorithm:
            Level 0: Hash each data block
            Level i: Hash pairs from level i-1
            Continue until single root hash remains
        """
        if not data_blocks:
            raise ValueError("Cannot build tree from empty data")
        
        # Level 0: Hash all data blocks (leaves)
        self.leaves = [self.hash_func.hash(block) for block in data_blocks]
        self.tree = [self.leaves.copy()]
        
        # Build tree bottom-up
        current_level = self.leaves.copy()
        
        while len(current_level) > 1:
            next_level = []
            
            # Process pairs
            for i in range(0, len(current_level), 2):
                left = current_level[i]
                
                # If odd number of nodes, duplicate last one
                if i + 1 < len(current_level):
                    right = current_level[i + 1]
                else:
                    right = left
                
                # Hash the pair (double SHA-256)
                combined = left + right
                parent_hash = hashlib.sha256(
                    hashlib.sha256(combined).digest()
                ).digest()
                
                next_level.append(parent_hash)
            
            self.tree.append(next_level)
            current_level = next_level
        
        # Root is the single hash at top level
        self.root_hash = current_level[0]
        return self.root_hash
    
    def get_root(self) -> bytes:
        """Get root hash of the tree"""
        if self.root_hash is None:
            raise ValueError("Tree not built yet")
        return self.root_hash
    
    def generate_proof(self, leaf_index: int) -> MerkleProof:
        """
        Generate Merkle proof for a specific leaf
        
        Args:
            leaf_index: Index of leaf to prove
            
        Returns:
            MerkleProof object containing proof path
            
        Complexity: O(log n) where n = number of leaves
        
        Proof consists of:
            - Sibling hashes along path from leaf to root
            - Direction indicators (left/right)
        """
        if not self.tree:
            raise ValueError("Tree not built yet")
        
        if leaf_index < 0 or leaf_index >= len(self.leaves):
            raise ValueError(f"Invalid leaf index: {leaf_index}")
        
        proof_hashes = []
        current_index = leaf_index
        
        # Walk up the tree, collecting sibling hashes
        for level in range(len(self.tree) - 1):
            level_nodes = self.tree[level]
            
            # Find sibling
            if current_index % 2 == 0:
                # Current node is left child
                sibling_index = current_index + 1
                direction = 'right'
            else:
                # Current node is right child
                sibling_index = current_index - 1
                direction = 'left'
            
            # Get sibling hash (or duplicate if at end)
            if sibling_index < len(level_nodes):
                sibling_hash = level_nodes[sibling_index]
            else:
                sibling_hash = level_nodes[current_index]
            
            proof_hashes.append((sibling_hash, direction))
            
            # Move to parent
            current_index = current_index // 2
        
        return MerkleProof(
            leaf_index=leaf_index,
            leaf_hash=self.leaves[leaf_index],
            proof_hashes=proof_hashes,
            root_hash=self.root_hash
        )
    
    def verify_proof(self, proof: MerkleProof) -> bool:
        """
        Verify a Merkle proof
        
        Args:
            proof: MerkleProof to verify
            
        Returns:
            True if proof is valid, False otherwise
            
        Complexity: O(log n) hash operations
        """
        return proof.verify()
    
    def verify_block(self, block_index: int, block_data: bytes) -> bool:
        """
        Verify a single block's integrity using the tree
        
        Args:
            block_index: Index of block to verify
            block_data: Actual block data
            
        Returns:
            True if block is valid, False otherwise
            
        Algorithm:
            1. Hash the block data
            2. Generate proof for this block
            3. Verify proof against root hash
        """
        if block_index >= len(self.leaves):
            return False
        
        # Hash the provided data
        block_hash = self.hash_func.hash(block_data)
        
        # Check if it matches stored leaf hash
        if block_hash != self.leaves[block_index]:
            return False
        
        # Generate and verify proof
        proof = self.generate_proof(block_index)
        return self.verify_proof(proof)
    
    def get_tree_height(self) -> int:
        """
        Get height of the tree
        
        Returns:
            Height (number of levels) = ceil(log2(n)) + 1
        """
        if not self.leaves:
            return 0
        return math.ceil(math.log2(len(self.leaves))) + 1
    
    def get_stats(self) -> dict:
        """Get statistics about the tree"""
        if not self.tree:
            return {
                'num_leaves': 0,
                'height': 0,
                'total_nodes': 0,
                'proof_size_bytes': 0
            }
        
        height = self.get_tree_height()
        proof_size = (height - 1) * self.algorithm.digest_size
        
        return {
            'num_leaves': len(self.leaves),
            'height': height,
            'total_nodes': sum(len(level) for level in self.tree),
            'proof_size_bytes': proof_size,
            'root_hash': self.root_hash.hex() if self.root_hash else None
        }


def hash_chain(data_list: List[bytes], algorithm: HashAlgorithm = HashAlgorithm.SHA256) -> bytes:
    """
    Create hash chain from list of data
    
    Used for audit logs and blockchain-style integrity
    
    Args:
        data_list: List of data items to chain
        algorithm: Hash algorithm to use
        
    Returns:
        Final hash in chain
        
    Algorithm:
        hash_0 = H(data_0)
        hash_1 = H(hash_0 || data_1)
        hash_2 = H(hash_1 || data_2)
        ...
        hash_n = H(hash_{n-1} || data_n)
    """
    if not data_list:
        raise ValueError("Cannot create chain from empty list")
    
    hash_func = HashFunction(algorithm)
    current_hash = hash_func.hash(b"GENESIS")
    
    for data in data_list:
        combined = current_hash + data
        current_hash = hash_func.hash(combined)
    
    return current_hash


# Convenience functions
def sha256(data: bytes) -> bytes:
    """Compute SHA-256 hash"""
    return hashlib.sha256(data).digest()


def sha512(data: bytes) -> bytes:
    """Compute SHA-512 hash"""
    return hashlib.sha512(data).digest()


def verify_hash(data: bytes, expected_hash: bytes, 
                algorithm: HashAlgorithm = HashAlgorithm.SHA256) -> bool:
    """Verify data matches expected hash"""
    hash_func = HashFunction(algorithm)
    return hash_func.verify(data, expected_hash)


if __name__ == "__main__":
    # Demonstration of hash functions and Merkle trees
    print("TruthFS Hash Module Demo")
    print("=" * 60)
    
    # 1. Basic hashing
    print("\n1. SHA-256 Hashing:")
    data = b"Hello, TruthFS!"
    hash_val = sha256(data)
    print(f"   Data: {data}")
    print(f"   SHA-256: {hash_val.hex()}")
    
    # Show avalanche effect
    data2 = b"hello, TruthFS!"  # Changed 'H' to 'h'
    hash_val2 = sha256(data2)
    print(f"\n   Data: {data2}")
    print(f"   SHA-256: {hash_val2.hex()}")
    print(f"   → Completely different despite 1 bit change!")
    
    # 2. Merkle tree
    print("\n2. Merkle Tree Construction:")
    blocks = [f"Block {i}".encode() for i in range(16)]
    
    tree = MerkleTree()
    root = tree.build(blocks)
    
    stats = tree.get_stats()
    print(f"   Blocks: {stats['num_leaves']}")
    print(f"   Tree height: {stats['height']}")
    print(f"   Total nodes: {stats['total_nodes']}")
    print(f"   Root hash: {root.hex()[:32]}...")
    print(f"   Proof size: {stats['proof_size_bytes']} bytes")
    
    # 3. Proof generation and verification
    print("\n3. Merkle Proof (for Block 7):")
    proof = tree.generate_proof(7)
    print(f"   Proof path length: {len(proof.proof_hashes)} hashes")
    print(f"   Proof size: {len(proof.proof_hashes) * 32} bytes")
    print(f"   Verification: {tree.verify_proof(proof)}")
    
    # 4. Block verification
    print("\n4. Block Integrity Verification:")
    is_valid = tree.verify_block(7, blocks[7])
    print(f"   Block 7 valid: {is_valid}")
    
    # Try with corrupted data
    corrupted = blocks[7] + b" corrupted"
    is_valid = tree.verify_block(7, corrupted)
    print(f"   Corrupted block valid: {is_valid}")
    
    print("\n" + "=" * 60)
    print("Demo complete!")
