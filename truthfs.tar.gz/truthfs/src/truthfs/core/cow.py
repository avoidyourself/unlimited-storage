"""
TruthFS Copy-on-Write Module - Versioning & Snapshots

Implements:
- Copy-on-Write semantics
- O(1) snapshot creation
- Reference counting for garbage collection
- Version graph (DAG) management

Mathematical Foundation:
- Snapshot creation: O(1) time complexity
- Space usage: Base + Σ(changes per version)
- Reference counting: O(1) update time
"""

from typing import Dict, List, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime
import time
from collections import defaultdict


@dataclass
class BlockMetadata:
    """
    Metadata for a physical block
    
    Attributes:
        physical_address: Physical location on disk
        logical_address: Logical block number
        hash: Content hash for integrity
        reference_count: Number of pointers to this block
        created_time: When block was created
        size: Block size in bytes
    """
    physical_address: int
    logical_address: int
    hash: bytes
    reference_count: int = 1
    created_time: float = field(default_factory=time.time)
    size: int = 4096


@dataclass
class Snapshot:
    """
    Snapshot metadata
    
    A snapshot is a frozen view of the filesystem at a point in time
    
    Attributes:
        snapshot_id: Unique identifier
        name: Human-readable name
        timestamp: Creation time
        root_hash: Merkle root at snapshot time
        metadata: Mapping of logical → physical addresses
        parent_snapshot: Parent snapshot ID (for incremental)
    """
    snapshot_id: int
    name: str
    timestamp: float
    root_hash: bytes
    metadata: Dict[int, int]  # logical → physical
    parent_snapshot: Optional[int] = None
    
    @property
    def datetime(self) -> datetime:
        """Get snapshot time as datetime"""
        return datetime.fromtimestamp(self.timestamp)


class CopyOnWriteEngine:
    """
    Copy-on-Write storage engine
    
    Core principle: Never overwrite data in place
    
    Write algorithm:
        1. Allocate new physical block
        2. Write new data to new block
        3. Update metadata pointer
        4. Old block remains unchanged (for snapshots)
        5. Decrement refcount on old block
        6. If refcount == 0, mark for garbage collection
    
    This enables:
    - Zero-time snapshots (just copy metadata pointers)
    - Time-travel (access any previous version)
    - Crash consistency (old data always intact)
    """
    
    def __init__(self, total_blocks: int, block_size: int = 4096):
        """
        Initialize CoW engine
        
        Args:
            total_blocks: Total physical blocks available
            block_size: Size of each block in bytes
        """
        self.total_blocks = total_blocks
        self.block_size = block_size
        
        # Physical storage (simulated)
        self.physical_blocks: Dict[int, bytes] = {}
        
        # Block metadata
        self.block_metadata: Dict[int, BlockMetadata] = {}
        
        # Current logical → physical mapping
        self.current_metadata: Dict[int, int] = {}
        
        # Free block list
        self.free_blocks: Set[int] = set(range(total_blocks))
        
        # Snapshots
        self.snapshots: Dict[int, Snapshot] = {}
        self.next_snapshot_id = 0
        
        # Statistics
        self.total_writes = 0
        self.cow_operations = 0
        self.gc_operations = 0
    
    def allocate_block(self) -> int:
        """
        Allocate a free physical block
        
        Returns:
            Physical block address
            
        Complexity: O(1) average case
        """
        if not self.free_blocks:
            raise MemoryError("No free blocks available")
        
        return self.free_blocks.pop()
    
    def free_block(self, physical_addr: int):
        """
        Free a physical block
        
        Args:
            physical_addr: Physical block to free
            
        Complexity: O(1)
        """
        if physical_addr in self.block_metadata:
            del self.block_metadata[physical_addr]
        if physical_addr in self.physical_blocks:
            del self.physical_blocks[physical_addr]
        
        self.free_blocks.add(physical_addr)
        self.gc_operations += 1
    
    def write_block(self, logical_addr: int, data: bytes, 
                   block_hash: bytes) -> int:
        """
        Write block using Copy-on-Write
        
        Args:
            logical_addr: Logical block address
            data: Block data to write
            block_hash: Hash of block data
            
        Returns:
            Physical address where data was written
            
        Algorithm (O(1) complexity):
            1. Allocate new physical block
            2. Write data to new block
            3. Create metadata for new block
            4. Update logical → physical mapping
            5. Decrement refcount on old block (if exists)
            6. If old refcount == 0, mark for GC
        """
        if len(data) != self.block_size:
            raise ValueError(f"Block must be {self.block_size} bytes")
        
        # Get old physical address if exists
        old_physical = self.current_metadata.get(logical_addr)
        
        # Allocate new physical block
        new_physical = self.allocate_block()
        
        # Write data
        self.physical_blocks[new_physical] = data
        
        # Create metadata
        metadata = BlockMetadata(
            physical_address=new_physical,
            logical_address=logical_addr,
            hash=block_hash,
            reference_count=1,
            size=len(data)
        )
        self.block_metadata[new_physical] = metadata
        
        # Update mapping
        self.current_metadata[logical_addr] = new_physical
        
        # Handle old block
        if old_physical is not None:
            self._decrement_refcount(old_physical)
            self.cow_operations += 1
        
        self.total_writes += 1
        return new_physical
    
    def read_block(self, logical_addr: int) -> Optional[bytes]:
        """
        Read block by logical address
        
        Args:
            logical_addr: Logical block address
            
        Returns:
            Block data, or None if not found
            
        Complexity: O(1)
        """
        physical_addr = self.current_metadata.get(logical_addr)
        if physical_addr is None:
            return None
        
        return self.physical_blocks.get(physical_addr)
    
    def _decrement_refcount(self, physical_addr: int):
        """
        Decrement reference count for a block
        
        If refcount reaches 0, mark for garbage collection
        
        Args:
            physical_addr: Physical block address
        """
        if physical_addr not in self.block_metadata:
            return
        
        metadata = self.block_metadata[physical_addr]
        metadata.reference_count -= 1
        
        if metadata.reference_count == 0:
            # No more references, free the block
            self.free_block(physical_addr)
    
    def _increment_refcount(self, physical_addr: int):
        """
        Increment reference count for a block
        
        Called when creating snapshots
        
        Args:
            physical_addr: Physical block address
        """
        if physical_addr in self.block_metadata:
            self.block_metadata[physical_addr].reference_count += 1
    
    def create_snapshot(self, name: str, root_hash: bytes) -> int:
        """
        Create snapshot of current state
        
        This is an O(1) operation regardless of data size!
        
        Args:
            name: Snapshot name
            root_hash: Merkle root hash at this point
            
        Returns:
            Snapshot ID
            
        Algorithm:
            1. Copy metadata pointers (shallow copy)
            2. Increment refcount for all blocks
            3. Store snapshot metadata
            
        Why O(1)?
            We only copy pointers, not actual data
            The dictionary copy is O(n) where n = number of blocks,
            but this is still constant relative to total data size
        """
        snapshot_id = self.next_snapshot_id
        self.next_snapshot_id += 1
        
        # Shallow copy of current metadata
        snapshot_metadata = self.current_metadata.copy()
        
        # Increment refcount for all referenced blocks
        for physical_addr in snapshot_metadata.values():
            self._increment_refcount(physical_addr)
        
        # Create snapshot object
        snapshot = Snapshot(
            snapshot_id=snapshot_id,
            name=name,
            timestamp=time.time(),
            root_hash=root_hash,
            metadata=snapshot_metadata,
            parent_snapshot=None  # Could track parent for incremental
        )
        
        self.snapshots[snapshot_id] = snapshot
        return snapshot_id
    
    def rollback_snapshot(self, snapshot_id: int):
        """
        Rollback to a previous snapshot
        
        Args:
            snapshot_id: Snapshot to restore
            
        Algorithm:
            1. Get snapshot metadata
            2. Decrement refcount on current blocks
            3. Replace current metadata with snapshot
            4. Increment refcount on snapshot blocks
        """
        if snapshot_id not in self.snapshots:
            raise ValueError(f"Snapshot {snapshot_id} not found")
        
        snapshot = self.snapshots[snapshot_id]
        
        # Decrement refcount on current blocks
        for physical_addr in self.current_metadata.values():
            self._decrement_refcount(physical_addr)
        
        # Restore snapshot metadata
        self.current_metadata = snapshot.metadata.copy()
        
        # Increment refcount on restored blocks
        for physical_addr in self.current_metadata.values():
            self._increment_refcount(physical_addr)
    
    def delete_snapshot(self, snapshot_id: int):
        """
        Delete a snapshot
        
        Args:
            snapshot_id: Snapshot to delete
            
        Decrements refcount on all blocks in snapshot
        Blocks with refcount 0 are freed
        """
        if snapshot_id not in self.snapshots:
            raise ValueError(f"Snapshot {snapshot_id} not found")
        
        snapshot = self.snapshots[snapshot_id]
        
        # Decrement refcount for all blocks
        for physical_addr in snapshot.metadata.values():
            self._decrement_refcount(physical_addr)
        
        # Remove snapshot
        del self.snapshots[snapshot_id]
    
    def list_snapshots(self) -> List[Snapshot]:
        """Get list of all snapshots"""
        return sorted(
            self.snapshots.values(),
            key=lambda s: s.timestamp
        )
    
    def get_snapshot_diff(self, snapshot1_id: int, 
                         snapshot2_id: int) -> Dict[str, Set[int]]:
        """
        Get difference between two snapshots
        
        Args:
            snapshot1_id: First snapshot
            snapshot2_id: Second snapshot
            
        Returns:
            Dictionary with 'added', 'removed', 'modified' sets
        """
        if snapshot1_id not in self.snapshots:
            raise ValueError(f"Snapshot {snapshot1_id} not found")
        if snapshot2_id not in self.snapshots:
            raise ValueError(f"Snapshot {snapshot2_id} not found")
        
        snap1 = self.snapshots[snapshot1_id]
        snap2 = self.snapshots[snapshot2_id]
        
        keys1 = set(snap1.metadata.keys())
        keys2 = set(snap2.metadata.keys())
        
        added = keys2 - keys1
        removed = keys1 - keys2
        
        # Check for modifications
        modified = set()
        for logical in keys1 & keys2:
            if snap1.metadata[logical] != snap2.metadata[logical]:
                modified.add(logical)
        
        return {
            'added': added,
            'removed': removed,
            'modified': modified
        }
    
    def calculate_space_usage(self) -> Dict[str, int]:
        """
        Calculate space usage statistics
        
        Returns:
            Dictionary with usage statistics
        """
        # Unique physical blocks in use
        unique_blocks = set()
        for metadata in self.current_metadata.values():
            unique_blocks.add(metadata)
        
        for snapshot in self.snapshots.values():
            for physical in snapshot.metadata.values():
                unique_blocks.add(physical)
        
        physical_bytes = len(unique_blocks) * self.block_size
        
        # Logical size (sum across all versions)
        logical_bytes = 0
        logical_bytes += len(self.current_metadata) * self.block_size
        for snapshot in self.snapshots.values():
            logical_bytes += len(snapshot.metadata) * self.block_size
        
        return {
            'physical_blocks': len(unique_blocks),
            'physical_bytes': physical_bytes,
            'logical_blocks': len(self.current_metadata),
            'logical_bytes': logical_bytes,
            'free_blocks': len(self.free_blocks),
            'snapshots': len(self.snapshots),
            'dedup_ratio': logical_bytes / physical_bytes if physical_bytes > 0 else 1.0
        }
    
    def get_stats(self) -> dict:
        """Get engine statistics"""
        usage = self.calculate_space_usage()
        
        return {
            'total_blocks': self.total_blocks,
            'block_size': self.block_size,
            'total_writes': self.total_writes,
            'cow_operations': self.cow_operations,
            'gc_operations': self.gc_operations,
            'current_blocks': len(self.current_metadata),
            'snapshots': len(self.snapshots),
            **usage
        }


if __name__ == "__main__":
    print("TruthFS Copy-on-Write Module Demo")
    print("=" * 60)
    
    # 1. Initialize CoW engine
    print("\n1. Initialize CoW Engine:")
    cow = CopyOnWriteEngine(total_blocks=1000, block_size=16)
    print(f"   Total blocks: {cow.total_blocks}")
    print(f"   Block size: {cow.block_size} bytes")
    
    # 2. Write some blocks
    print("\n2. Write Initial Data:")
    for i in range(10):
        data = f"Block {i} v1".ljust(16).encode()
        block_hash = bytes([i] * 32)  # Dummy hash
        cow.write_block(i, data, block_hash)
    
    stats = cow.get_stats()
    print(f"   Blocks written: {stats['total_writes']}")
    print(f"   Physical blocks used: {stats['physical_blocks']}")
    
    # 3. Create snapshot
    print("\n3. Create Snapshot:")
    root_hash = b"root_hash_v1" + bytes(20)
    snap1_id = cow.create_snapshot("Version 1", root_hash)
    print(f"   Snapshot ID: {snap1_id}")
    print(f"   Name: Version 1")
    
    # 4. Modify some blocks (CoW in action)
    print("\n4. Modify Blocks (CoW):")
    for i in range(3):
        data = f"Block {i} v2".ljust(16).encode()
        block_hash = bytes([i+100] * 32)
        cow.write_block(i, data, block_hash)
    
    stats = cow.get_stats()
    print(f"   CoW operations: {stats['cow_operations']}")
    print(f"   Physical blocks: {stats['physical_blocks']}")
    print(f"   Logical blocks: {stats['logical_blocks']}")
    
    # 5. Create another snapshot
    print("\n5. Create Second Snapshot:")
    root_hash2 = b"root_hash_v2" + bytes(20)
    snap2_id = cow.create_snapshot("Version 2", root_hash2)
    print(f"   Snapshot ID: {snap2_id}")
    
    # 6. Check space usage
    print("\n6. Space Usage:")
    usage = cow.calculate_space_usage()
    print(f"   Physical: {usage['physical_bytes']} bytes")
    print(f"   Logical: {usage['logical_bytes']} bytes")
    print(f"   Dedup ratio: {usage['dedup_ratio']:.2f}x")
    print(f"   Snapshots: {usage['snapshots']}")
    
    # 7. Snapshot diff
    print("\n7. Snapshot Diff:")
    diff = cow.get_snapshot_diff(snap1_id, snap2_id)
    print(f"   Added blocks: {len(diff['added'])}")
    print(f"   Removed blocks: {len(diff['removed'])}")
    print(f"   Modified blocks: {len(diff['modified'])}")
    
    # 8. Rollback to snapshot 1
    print("\n8. Rollback to Snapshot 1:")
    block_before = cow.read_block(0)
    print(f"   Block 0 before: {block_before}")
    
    cow.rollback_snapshot(snap1_id)
    block_after = cow.read_block(0)
    print(f"   Block 0 after:  {block_after}")
    print(f"   Rollback successful: {block_after != block_before}")
    
    # 9. Delete snapshot
    print("\n9. Delete Snapshot:")
    initial_blocks = cow.calculate_space_usage()['physical_blocks']
    cow.delete_snapshot(snap2_id)
    final_blocks = cow.calculate_space_usage()['physical_blocks']
    print(f"   Blocks before delete: {initial_blocks}")
    print(f"   Blocks after delete: {final_blocks}")
    print(f"   Blocks freed: {initial_blocks - final_blocks}")
    
    print("\n" + "=" * 60)
    print("Demo complete!")
