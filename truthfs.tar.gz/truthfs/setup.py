#!/usr/bin/env python3
"""
TruthFS Setup Script
"""

from setuptools import setup, find_packages, Extension
from pathlib import Path

# Read README
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text() if readme_file.exists() else ""

# Native extensions for performance
extensions = [
    Extension(
        'truthfs.native.hash_accel',
        sources=['src/native/hash_accel.c'],
        extra_compile_args=['-O3', '-march=native']
    ),
    Extension(
        'truthfs.native.xor_simd',
        sources=['src/native/xor_simd.c'],
        extra_compile_args=['-O3', '-march=native', '-msse4.2']
    ),
    Extension(
        'truthfs.native.rs_gf256',
        sources=['src/native/rs_gf256.c'],
        extra_compile_args=['-O3', '-march=native']
    )
]

setup(
    name='truthfs',
    version='1.0.0',
    description='Mathematically Verified Layered Storage System',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='TruthFS Contributors',
    author_email='dev@truthfs.org',
    url='https://github.com/truthfs/truthfs',
    license='MIT',
    
    packages=find_packages('src'),
    package_dir={'': 'src'},
    
    ext_modules=extensions,
    
    install_requires=[
        'numpy>=1.24.0',
        'reedsolo>=1.7.0',
        'lz4>=4.3.0',
        'zstandard>=0.22.0',
        'cryptography>=41.0.0',
        'flask>=3.0.0',
        'flask-restful>=0.3.10',
        'pyyaml>=6.0.1',
        'click>=8.1.7',
    ],
    
    extras_require={
        'dev': [
            'pytest>=7.4.0',
            'pytest-cov>=4.1.0',
            'pytest-benchmark>=4.0.0',
            'black>=23.0.0',
            'flake8>=6.1.0',
            'mypy>=1.5.0',
        ]
    },
    
    entry_points={
        'console_scripts': [
            'truthfs=truthfs.api.cli:main',
        ]
    },
    
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Intended Audience :: System Administrators',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Topic :: System :: Filesystems',
        'Topic :: System :: Archiving :: Backup',
        'Topic :: Security :: Cryptography',
    ],
    
    python_requires='>=3.9',
    
    keywords='filesystem storage deduplication raid merkle-tree copy-on-write',
)
